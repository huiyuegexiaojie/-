bl_info = {
    "name": "小杰csv导入工具）",
    "author": "自定义",
    "version": (1, 0, 6),
    "blender": (3, 6, 0),
    "location": "View3D > Sidebar > MINIX 工具",
    "description": "从CSV批量导入带独立UV的方块、楼梯、薄板等模型（支持上色水泥块+玻璃块+棉花块按ID+Data映射颜色）",
    "category": "Import-Export",
}
import bpy
import csv
import os
import math
import bmesh
import sys
from mathutils import Vector, Euler
from collections import defaultdict
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, PointerProperty
from bpy.types import PropertyGroup, AddonPreferences

# ===================== 编码处理（解决中文路径乱码）=====================
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

# ===================== 全局常量（解决作用域问题） =====================
# 方块尺寸
BLOCK_SIZE = 1

# CSV列索引
MINI_X_COL = 0
MINI_Y_COL = 1
MINI_Z_COL = 2
NAME_COL = 5
DATA_COL = 4
ID_COL = 3  # CSV中ID列的索引（第4列，索引从0开始）

# 各类方块规则（提升为全局常量）
STAIR_RULES = {
    0: (False, 0.0),
    2: (False, math.pi/2),
    1: (False, math.pi),
    3: (False, 3*math.pi/2),
    4: (True, 0.0),
    6: (True, math.pi/2),
    5: (True, math.pi),
    7: (True, 3*math.pi/2)
}

Y_AXIS_FLIP_MAP = {
    math.pi/2: 3*math.pi/2,
    3*math.pi/2: math.pi/2,
    0.0: 0.0,
    math.pi: math.pi
}

SLAB_RULES = {
    3: ("bottom", 0.25),
    0: ("bottom", 0.5),
    5: ("bottom", 0.75),
    2: ("full", 1.0),
    4: ("top", 0.25),
    1: ("top", 0.5),
    6: ("top", 0.75),
}

VERTICAL_SLAB_RULES = {
    0: ("east", 0.25),
    4: ("east", 0.5),
    8: ("east", 0.75),
    12: ("east", 1.0),
    2: ("south", 0.25),
    6: ("south", 0.5),
    10: ("south", 0.25),
    14: ("south", 1.0),
    1: ("west", 0.25),
    5: ("west", 0.5),
    9: ("west", 0.75),
    13: ("west", 1.0),
    3: ("north", 0.25),
    7: ("north", 0.5),
    11: ("north", 0.75),
    15: ("north", 1.0)
}

VERTICAL_PANEL_TO_SLAB_DATA_MAP = {
    0: 4,
    1: 5,
    2: 6,
    3: 7,
    8: 12,
    9: 13,
    10: 14,
    11: 15
}

# ===================== 上色水泥块颜色映射表（ID+Data → 颜色代码） =====================
COLORED_CEMENT_COLOR_MAP = {
    (681, 11): "#FFCDD2",
    (681, 10): "#F8BBD0",
    (667, 2): "#E1BEE7",
    (667, 3): "#D1C4E9",
    (667, 4): "#C5CAE9",
    (667, 5): "#BBDEFB",
    (667, 6): "#B3E5FC",
    (667, 7): "#B2EBF2",
    (667, 8): "#B2DFDB",
    (667, 9): "#C8E6C9",
    (667, 10): "#DCEDC8",
    (667, 11): "#F0F4C3",
    (667, 12): "#FFF9C4",
    (667, 13): "#FFECB3",
    (667, 14): "#FFE0B2",
    (667, 15): "#FFCCBC",
    (669, 3): "#000000",
    (680, 9): "#EF9A9A",
    (680, 8): "#F48FB1",
    (668, 4): "#CE93D8",
    (1966, 0): "#B39DDB",
    (668, 6): "#9FA8DA",
    (670, 0): "#90CAF9",
    (668, 8): "#81D4FA",
    (668, 9): "#80DEEA",
    (668, 10): "#80CBC4",
    (668, 11): "#A5D6A7",
    (668, 12): "#C5E1A5",
    (668, 13): "#E6EE9C",
    (668, 14): "#FFF59D",
    (668, 15): "#FFE082",
    (1965, 0): "#FFCC80",
    (669, 1): "#FFAB91",
    (669, 2): "#D7CCC8",
    (667, 0): "#FFFFFF",
    (679, 7): "#E57373",
    (679, 6): "#F06292",
    (669, 6): "#BA68C8",
    (669, 7): "#9575CD",
    (669, 8): "#7986CB",
    (669, 9): "#64B5F6",
    (669, 10): "#4FC3F7",
    (669, 11): "#4DD0E1",
    (669, 12): "#4DB6AC",
    (669, 13): "#81C784",
    (669, 14): "#AED581",
    (669, 15): "#DCE775",
    (1964, 0): "#FFF176",
    (670, 1): "#FFD54F",
    (670, 2): "#FFB74D",
    (670, 3): "#FF8A65",
    (670, 4): "#BCAAA4",
    (670, 5): "#EEEEEE",
    (678, 5): "#EF5350",
    (678, 4): "#EC407A",
    (670, 8): "#AB47BC",
    (670, 9): "#7E57C2",
    (670, 10): "#5C6BC0",
    (670, 11): "#42A5F5",
    (670, 12): "#29B6F6",
    (670, 13): "#26C6DA",
    (670, 14): "#26A69A",
    (670, 15): "#66BB6A",
    (680, 3): "#9CCC65",
    (671, 1): "#D4E157",
    (671, 2): "#FFEE58",
    (671, 3): "#FFCA28",
    (671, 4): "#FFA726",
    (671, 5): "#FF7043",
    (671, 6): "#A1887F",
    (671, 7): "#E0E0E0",
    (677, 3): "#F44336",
    (677, 2): "#E91E63",
    (669, 0): "#9C27B0",
    (671, 11): "#673AB7",
    (671, 12): "#3F51B5",
    (671, 13): "#2196F3",
    (671, 14): "#03A9F4",
    (671, 15): "#00BCD4",
    (672, 3): "#009688",
    (672, 1): "#4CAF50",
    (672, 2): "#8BC34A",
    (672, 0): "#CDDC39",
    (672, 4): "#FFEB3B",
    (672, 5): "#FFC107",
    (672, 6): "#FF9800",
    (672, 7): "#FF5722",
    (672, 8): "#8D6E63",
    (675, 0): "#BDBDBD",
    (676, 1): "#E53935",
    (677, 10): "#D81B60",
    (672, 12): "#8E24AA",
    (672, 13): "#5E35B1",
    (672, 14): "#3949AB",
    (678, 0): "#1E88E5",
    (669, 5): "#039BE5",
    (673, 1): "#00ACC1",
    (673, 2): "#00897B",
    (673, 3): "#43A047",
    (673, 4): "#7CB342",
    (673, 5): "#C0CA33",
    (673, 6): "#FDD835",
    (673, 7): "#FFB300",
    (673, 8): "#FB8C00",
    (673, 9): "#F4511E",
    (1969, 0): "#795548",
    (673, 11): "#9E9E9E",
    (674, 15): "#D32F2F",
    (681, 0): "#C2185B",
    (673, 14): "#7B1FA2",
    (673, 15): "#512DA8",
    (675, 15): "#303F9F",
    (674, 1): "#1976D2",
    (674, 2): "#0288D1",
    (674, 3): "#0097A7",
    (674, 4): "#00796B",
    (674, 5): "#388E3C",
    (674, 6): "#689F38",
    (674, 7): "#AFB42B",
    (674, 8): "#FBC02D",
    (674, 9): "#FFA000",
    (674, 10): "#F57C00",
    (674, 11): "#E64A19",
    (674, 12): "#6D4C41",
    (674, 13): "#757575",
    (673, 13): "#C62828",
    (673, 12): "#AD1457",
    (677, 0): "#6A1B9A",
    (675, 1): "#4527A0",
    (675, 2): "#283593",
    (675, 3): "#1565C0",
    (675, 4): "#0277BD",
    (675, 5): "#00838F",
    (675, 6): "#00695C",
    (680, 0): "#2E7D32",
    (675, 8): "#558B2F",
    (675, 9): "#9E9D24",
    (675, 10): "#F9A825",
    (675, 11): "#FF8F00",
    (668, 0): "#EF6C00",
    (675, 13): "#D84315",
    (679, 0): "#5D4037",
    (674, 0): "#616161",
    (672, 11): "#B71C1C",
    (672, 10): "#880E4F",
    (1970, 0): "#4A148C",
    (1962, 0): "#311B92",
    (1968, 0): "#1A237E",
    (676, 5): "#0D47A1",
    (676, 6): "#01579B",
    (676, 7): "#006064",
    (676, 8): "#004D40",
    (1971, 0): "#1B5E20",
    (676, 10): "#33691E",
    (1967, 0): "#827717",
    (676, 12): "#F57F17",
    (676, 13): "#FF6F00",
    (676, 14): "#E65100",
    (676, 15): "#BF360C",
    (672, 9): "#4E342E",
    (677, 1): "#424242",
    (671, 9): "#D50000",
    (671, 8): "#C61161",
    (677, 4): "#AC01F8",
    (677, 5): "#6400E7",
    (677, 6): "#355EF1",
    (677, 7): "#1288DB",
    (677, 8): "#07B3CE",
    (677, 9): "#04B5D2",
    (676, 0): "#00BFA5",
    (677, 11): "#00C853",
    (677, 12): "#66DA18",
    (1963, 0): "#AEEA00",
    (677, 14): "#FFD600",
    (677, 15): "#FFA801",
    (672, 15): "#FF6D00",
    (678, 1): "#E12809",
    (678, 2): "#3E2723",
    (682, 0): "#212121",
    (670, 7): "#FF1744",
    (670, 6): "#F40352",
    (678, 6): "#DC0AAF",
    (678, 7): "#651FFF",
    (678, 8): "#5352E2",
    (678, 9): "#2979FF",
    (678, 10): "#00B0FF",
    (678, 11): "#00E5FF",
    (678, 12): "#1DE9B6",
    (678, 13): "#00E676",
    (678, 14): "#76FF03",
    (678, 15): "#C6FF00",
    (675, 14): "#FFEA00",
    (679, 1): "#FEBF01",
    (679, 2): "#FE8B02",
    (1960, 0): "#FD3A03",
    (679, 4): "#ECEFF1",
    (679, 5): "#627B8A",
    (673, 0): "#FF5152",
    (669, 4): "#FF4081",
    (679, 8): "#E040FB",
    (679, 9): "#B388FF",
    (679, 10): "#5A69F4",
    (679, 11): "#5480EA",
    (679, 12): "#40C4FF",
    (679, 13): "#2CEAEA",
    (679, 14): "#71EAC8",
    (679, 15): "#69F0AE",
    (675, 7): "#B2FF59",
    (680, 1): "#EEFB41",
    (680, 2): "#FFFF00",
    (671, 0): "#FFD740",
    (1961, 0): "#FEA73F",
    (680, 5): "#FF6E40",
    (680, 6): "#CFD8DC",
    (680, 7): "#586C77",
    (668, 3): "#FE857C",
    (668, 2): "#FF80AB",
    (680, 10): "#EA80FC",
    (680, 11): "#B485F8",
    (680, 12): "#9296F1",
    (680, 13): "#8AA5EE",
    (680, 14): "#96B2D2",
    (680, 15): "#8EEAEA",
    (674, 14): "#A8FBE8",
    (681, 1): "#BAEFC5",
    (681, 2): "#CDF48B",
    (681, 3): "#F4FF81",
    (681, 4): "#FFFF8D",
    (681, 5): "#FFE57F",
    (681, 6): "#FECB7D",
    (681, 7): "#FF9E80",
    (681, 8): "#90A4AE",
    (681, 9): "#3F454D",
    (667, 1): "#FBD4D7",
    (668, 1): "#F9C0CB",
    (681, 12): "#EFD2F0",
    (681, 13): "#E8DAF0",
    (681, 14): "#D7E0F1",
    (681, 15): "#D8DDED",
    (675, 12): "#D9F3FF",
    (682, 1): "#D3E8EB",
    (682, 2): "#D3E3E0",
    (682, 3): "#DEE8D6",
    (682, 4): "#EDF9DF",
    (682, 5): "#F7F0D3",
    (682, 6): "#FFFCDD",
    (682, 7): "#FFF0D3",
    (682, 8): "#FFEBD5",
    (682, 9): "#FFDFDD",
    (682, 10): "#7A8E9B",
    (682, 11): "#293138"
}

# ===================== 玻璃块颜色映射表 =====================
GLASS_COLOR_MAP = {
    (634, 1): "#FFCDD2",
    (633, 1): "#F8BBD0",
    (633, 2): "#E1BEE7",
    (633, 3): "#D1C4E9",
    (633, 4): "#C5CAE9",
    (633, 5): "#BBDEFB",
    (633, 6): "#B3E5FC",
    (633, 7): "#B2EBF2",
    (633, 8): "#B2DFDB",
    (633, 9): "#C8E6C9",
    (633, 10): "#F0F4C3",
    (633, 11): "#E6EE9C",
    (633, 12): "#FFF59D",
    (633, 13): "#FFE082",
    (633, 14): "#FFCC80",
    (633, 15): "#FFAB91",
    (635, 3): "#000000",
    (634, 2): "#EF9A9A",
    (634, 3): "#F48FB1",
    (634, 4): "#CE93D8",
    (1930, 0): "#B39DDB",
    (634, 6): "#9FA8DA",
    (636, 0): "#90CAF9",
    (634, 8): "#81D4FA",
    (634, 9): "#80DEEA",
    (634, 10): "#80CBC4",
    (634, 11): "#A5D6A7",
    (634, 12): "#C5E1A5",
    (634, 13): "#E6EE9C",
    (634, 14): "#FFF59D",
    (634, 15): "#FFE082",
    (1929, 0): "#FFCC80",
    (635, 1): "#FFAB91",
    (635, 2): "#D7CCC8",
    (633, 0): "#FFFFFF",
    (635, 4): "#E57373",
    (639, 0): "#F06292",
    (635, 6): "#BA68C8",
    (635, 7): "#9575CD",
    (635, 8): "#7986CB",
    (635, 9): "#64B5F6",
    (635, 10): "#4FC3F7",
    (635, 11): "#4DD0E1",
    (635, 12): "#4DB6AC",
    (635, 13): "#81C784",
    (635, 14): "#AED581",
    (635, 15): "#DCE775",
    (1928, 0): "#FFF176",
    (636, 1): "#FFD54F",
    (636, 2): "#FFB74D",
    (636, 3): "#FF8A65",
    (636, 4): "#BCAAA4",
    (636, 5): "#EEEEEE",
    (636, 6): "#EF5350",
    (636, 7): "#EC407A",
    (636, 8): "#AB47BC",
    (636, 9): "#7E57C2",
    (636, 10): "#5C6BC0",
    (636, 11): "#42A5F5",
    (636, 12): "#29B6F6",
    (636, 13): "#26C6DA",
    (636, 14): "#26A69A",
    (636, 15): "#66BB6A",
    (646, 3): "#9CCC65",
    (637, 1): "#D4E157",
    (637, 2): "#FFEE58",
    (637, 3): "#FFCA28",
    (637, 4): "#FFA726",
    (637, 5): "#FF7043",
    (637, 6): "#A1887F",
    (637, 7): "#E0E0E0",
    (637, 8): "#F44336",
    (637, 9): "#E91E63",
    (635, 0): "#9C27B0",
    (637, 11): "#673AB7",
    (637, 12): "#3F51B5",
    (637, 13): "#2196F3",
    (637, 14): "#03A9F4",
    (637, 15): "#00BCD4",
    (638, 3): "#009688",
    (638, 1): "#4CAF50",
    (638, 2): "#8BC34A",
    (638, 0): "#CDDC39",
    (638, 4): "#FFEB3B",
    (638, 5): "#FFC107",
    (638, 6): "#FF9800",
    (638, 7): "#FF5722",
    (638, 8): "#8D6E63",
    (641, 0): "#BDBDBD",
    (638, 10): "#E53935",
    (638, 11): "#D81B60",
    (638, 12): "#8E24AA",
    (638, 13): "#5E35B1",
    (638, 14): "#3949AB",
    (644, 0): "#1E88E5",
    (635, 5): "#039BE5",
    (639, 1): "#00ACC1",
    (639, 2): "#00897B",
    (639, 3): "#43A047",
    (639, 4): "#7CB342",
    (639, 5): "#C0CA33",
    (639, 6): "#FDD835",
    (639, 7): "#FFB300",
    (639, 8): "#FB8C00",
    (639, 9): "#F4511E",
    (1933, 0): "#795548",
    (639, 11): "#9E9E9E",
    (639, 12): "#D32F2F",
    (639, 13): "#C2185B",
    (639, 14): "#7B1FA2",
    (639, 15): "#512DA8",
    (641, 15): "#303F9F",
    (640, 1): "#1976D2",
    (640, 2): "#0288D1",
    (640, 3): "#0097A7",
    (640, 4): "#00796B",
    (640, 5): "#388E3C",
    (640, 6): "#689F38",
    (640, 7): "#AFB42B",
    (640, 8): "#FBC02D",
    (640, 9): "#FFA000",
    (640, 10): "#F57C00",
    (640, 11): "#E64A19",
    (640, 12): "#6D4C41",
    (640, 13): "#757575",
    (647, 0): "#C62828",
    (640, 15): "#AD1457",
    (643, 0): "#6A1B9A",
    (641, 1): "#4527A0",
    (641, 2): "#283593",
    (641, 3): "#1565C0",
    (641, 4): "#0277BD",
    (641, 5): "#00838F",
    (641, 6): "#00695C",
    (646, 0): "#2E7D32",
    (641, 8): "#558B2F",
    (641, 9): "#9E9D24",
    (641, 10): "#F9A825",
    (641, 11): "#FF8F00",
    (634, 0): "#EF6C00",
    (641, 13): "#D84315",
    (645, 0): "#5D4037",
    (640, 0): "#424242",
    (643, 10): "#D50000",
    (642, 1): "#C61161",
    (1934, 0): "#AC01F8",
    (1926, 0): "#6400E7",
    (1932, 0): "#355EF1",
    (642, 5): "#1288DB",
    (642, 6): "#07B3CE",
    (642, 7): "#04B5D2",
    (642, 8): "#00BFA5",
    (1935, 0): "#00C853",
    (642, 10): "#66DA18",
    (1931, 0): "#AEEA00",
    (642, 12): "#FFD600",
    (642, 13): "#FFA801",
    (642, 14): "#FF6D00",
    (642, 15): "#E12809",
    (638, 9): "#3E2723",
    (643, 1): "#212121",
    (643, 2): "#FF1744",
    (643, 3): "#F40352",
    (643, 4): "#DC0AAF",
    (643, 5): "#651FFF",
    (643, 6): "#5352E2",
    (643, 7): "#2979FF",
    (643, 8): "#00B0FF",
    (643, 9): "#00E5FF",
    (642, 0): "#1DE9B6",
    (643, 11): "#00E676",
    (643, 12): "#76FF03",
    (1927, 0): "#C6FF00",
    (643, 14): "#FFEA00",
    (643, 15): "#FEBF01",
    (638, 15): "#FE8B02",
    (644, 1): "#FD3A03",
    (644, 2): "#ECEFF1",
    (648, 0): "#627B8A",
    (644, 4): "#FF5152",
    (644, 5): "#FF4081",
    (644, 6): "#E040FB",
    (644, 7): "#B388FF",
    (644, 8): "#5A69F4",
    (644, 9): "#5480EA",
    (644, 10): "#40C4FF",
    (644, 11): "#2CEAEA",
    (644, 12): "#71EAC8",
    (644, 13): "#69F0AE",
    (644, 14): "#B2FF59",
    (644, 15): "#EEFB41",
    (641, 14): "#FFFF00",
    (645, 1): "#FFD740",
    (645, 2): "#FEA73F",
    (1924, 0): "#FF6E40",
    (645, 4): "#CFD8DC",
    (645, 5): "#586C77",
    (645, 6): "#FE857C",
    (645, 7): "#FF80AB",
    (645, 8): "#EA80FC",
    (645, 9): "#B485F8",
    (645, 10): "#9296F1",
    (645, 11): "#8AA5EE",
    (645, 12): "#96B2D2",
    (645, 13): "#8EEAEA",
    (645, 14): "#A8FBE8",
    (645, 15): "#BAEFC5",
    (641, 7): "#CDF48B",
    (646, 1): "#F4FF81",
    (646, 2): "#FFFF8D",
    (637, 0): "#FFE57F",
    (1925, 0): "#FECB7D",
    (646, 5): "#FF9E80",
    (646, 6): "#90A4AE",
    (646, 7): "#3F454D",
    (646, 8): "#FBD4D7",
    (646, 9): "#F9C0CB",
    (646, 10): "#EFD2F0",
    (646, 11): "#E8DAF0",
    (646, 12): "#D7E0F1",
    (646, 13): "#D8DDED",
    (646, 14): "#D9F3FF",
    (646, 15): "#D3E8EB",
    (640, 14): "#D3E3E0",
    (647, 1): "#DEE8D6",
    (647, 2): "#EDF9DF",
    (647, 3): "#F7F0D3",
    (647, 4): "#FFFCDD",
    (647, 5): "#FFF0D3",
    (647, 6): "#FFEBD5",
    (647, 7): "#FFDFDD",
    (647, 8): "#7A8E9B",
    (647, 9): "#293138",
    (647, 10): "#FFCDD2",
    (647, 11): "#F8BBD0",
    (647, 12): "#E1BEE7",
    (647, 13): "#D1C4E9",
    (647, 14): "#C5CAE9",
    (647, 15): "#BBDEFB",
    (641, 12): "#B3E5FC",
    (648, 1): "#B2EBF2",
    (648, 2): "#B2DFDB",
    (648, 3): "#C8E6C9",
    (648, 4): "#DCEDC8",
    (648, 5): "#F0F4C3",
    (648, 6): "#FFF9C4",
    (648, 7): "#FFECB3",
    (648, 8): "#FFE0B2",
    (648, 9): "#FFCCBC",
    (648, 10): "#000000",
    (648, 11): "#EF9A9A"
}

# ===================== 棉花块颜色映射表（ID+Data → 颜色代码） =====================
COTTON_COLOR_MAP = {
    # ID:600（16组）
    (600, 0): "#FFFFFF",
    (600, 1): "#F8BBD0",
    (600, 2): "#E1BEE7",
    (600, 3): "#D1C4E9",
    (600, 4): "#C5CAE9",
    (600, 5): "#BBDEFB",
    (600, 6): "#B3E5FC",
    (600, 7): "#B2EBF2",
    (600, 8): "#B2DFDB",
    (600, 9): "#C8E6C9",
    (600, 10): "#DCEDC8",
    (600, 11): "#F0F4C3",
    (600, 12): "#FFF9C4",
    (600, 13): "#FFECB3",
    (600, 14): "#FFE0B2",
    (600, 15): "#FFCCBC",
    
    # ID:601（16组）
    (601, 0): "#EF6C00",
    (601, 1): "#FFCDD2",
    (601, 2): "#EF9A9A",
    (601, 3): "#F48FB1",
    (601, 4): "#CE93D8",
    (601, 6): "#9FA8DA",
    (601, 8): "#81D4FA",
    (601, 9): "#80DEEA",
    (601, 10): "#80CBC4",
    (601, 11): "#A5D6A7",
    (601, 12): "#C5E1A5",
    (601, 13): "#E6EE9C",
    (601, 14): "#FFF59D",
    (601, 15): "#FFE082",
    
    # ID:602（16组）
    (602, 0): "#9C27B0",
    (602, 1): "#FFAB91",
    (602, 2): "#D7CCC8",
    (602, 3): "#000000",
    (602, 4): "#E57373",
    (602, 5): "#039BE5",
    (602, 6): "#BA68C8",
    (602, 7): "#9575CD",
    (602, 8): "#7986CB",
    (602, 9): "#64B5F6",
    (602, 10): "#4FC3F7",
    (602, 11): "#4DD0E1",
    (602, 12): "#4DB6AC",
    (602, 13): "#81C784",
    (602, 14): "#AED581",
    (602, 15): "#DCE775",
    
    # ID:603（16组）
    (603, 0): "#90CAF9",
    (603, 1): "#FFD54F",
    (603, 2): "#FFB74D",
    (603, 3): "#FF8A65",
    (603, 4): "#BCAAA4",
    (603, 5): "#EEEEEE",
    (603, 6): "#EF5350",
    (603, 7): "#EC407A",
    (603, 8): "#AB47BC",
    (603, 9): "#7E57C2",
    (603, 10): "#5C6BC0",
    (603, 11): "#42A5F5",
    (603, 12): "#29B6F6",
    (603, 13): "#26C6DA",
    (603, 14): "#26A69A",
    (603, 15): "#66BB6A",
    
    # ID:604（16组）
    (604, 0): "#FFE57F",
    (604, 1): "#D4E157",
    (604, 2): "#FFEE58",
    (604, 3): "#FFCA28",
    (604, 4): "#FFA726",
    (604, 5): "#FF7043",
    (604, 6): "#A1887F",
    (604, 7): "#E0E0E0",
    (604, 8): "#F44336",
    (604, 9): "#E91E63",
    (604, 11): "#673AB7",
    (604, 12): "#3F51B5",
    (604, 13): "#2196F3",
    (604, 14): "#03A9F4",
    (604, 15): "#00BCD4",
    
    # ID:605（16组）
    (605, 0): "#CDDC39",
    (605, 1): "#4CAF50",
    (605, 2): "#8BC34A",
    (605, 3): "#009688",
    (605, 4): "#FFEB3B",
    (605, 5): "#FFC107",
    (605, 6): "#FF9800",
    (605, 7): "#FF5722",
    (605, 9): "#3E2723",
    (605, 10): "#E53935",
    (605, 11): "#D81B60",
    (605, 12): "#8E24AA",
    (605, 13): "#5E35B1",
    (605, 14): "#3949AB",
    (605, 15): "#FE8B02",
    
    # ID:606（16组）
    (606, 0): "#F06292",
    (606, 1): "#00ACC1",
    (606, 2): "#00897B",
    (606, 3): "#43A047",
    (606, 4): "#7CB342",
    (606, 5): "#C0CA33",
    (606, 6): "#FDD835",
    (606, 7): "#FFB300",
    (606, 8): "#FB8C00",
    (606, 9): "#F4511E",
    (606, 11): "#9E9E9E",
    (606, 12): "#D32F2F",
    (606, 13): "#C2185B",
    (606, 14): "#7B1FA2",
    (606, 15): "#512DA8",
    
    # ID:607（16组）
    (607, 0): "#424242",
    (607, 1): "#1976D2",
    (607, 2): "#0288D1",
    (607, 3): "#0097A7",
    (607, 4): "#00796B",
    (607, 5): "#388E3C",
    (607, 6): "#689F38",
    (607, 7): "#AFB42B",
    (607, 8): "#FBC02D",
    (607, 9): "#FFA000",
    (607, 10): "#F57C00",
    (607, 11): "#E64A19",
    (607, 12): "#6D4C41",
    (607, 13): "#757575",
    (607, 14): "#D3E3E0",
    (607, 15): "#AD1457",
    
    # ID:608（16组）
    (608, 0): "#8D6E63",
    (608, 1): "#4527A0",
    (608, 2): "#283593",
    (608, 3): "#1565C0",
    (608, 4): "#0277BD",
    (608, 5): "#00838F",
    (608, 6): "#00695C",
    (608, 8): "#558B2F",
    (608, 9): "#9E9D24",
    (608, 10): "#F9A825",
    (608, 11): "#FF8F00",
    (608, 12): "#B3E5FC",
    (608, 13): "#D84315",
    (608, 14): "#FFFF00",
    (608, 15): "#303F9F",
    
    # ID:609（16组）
    (609, 0): "#1DE9B6",
    (609, 1): "#C61161",
    (609, 5): "#1288DB",
    (609, 6): "#07B3CE",
    (609, 7): "#04B5D2",
    (609, 8): "#00BFA5",
    (609, 10): "#66DA18",
    (609, 12): "#FFD600",
    (609, 13): "#FFA801",
    (609, 14): "#FF6D00",
    (609, 15): "#E12809",
    
    # ID:610（16组）
    (610, 0): "#6A1B9A",
    (610, 1): "#212121",
    (610, 2): "#FF1744",
    (610, 3): "#F40352",
    (610, 4): "#DC0AAF",
    (610, 5): "#651FFF",
    (610, 6): "#5352E2",
    (610, 7): "#2979FF",
    (610, 8): "#00B0FF",
    (610, 9): "#00E5FF",
    (610, 10): "#D50000",
    (610, 11): "#00E676",
    (610, 12): "#76FF03",
    (610, 14): "#FFEA00",
    (610, 15): "#FEBF01",
    
    # ID:611（16组）
    (611, 0): "#BDBDBD",
    (611, 1): "#FD3A03",
    (611, 2): "#ECEFF1",
    (611, 4): "#FF5152",
    (611, 5): "#FF4081",
    (611, 6): "#E040FB",
    (611, 7): "#B388FF",
    (611, 8): "#5A69F4",
    (611, 9): "#5480EA",
    (611, 10): "#40C4FF",
    (611, 11): "#2CEAEA",
    (611, 12): "#71EAC8",
    (611, 13): "#69F0AE",
    (611, 14): "#B2FF59",
    (611, 15): "#EEFB41",
    
    # ID:612（16组）
    (612, 0): "#5D4037",
    (612, 1): "#FFD740",
    (612, 2): "#FEA73F",
    (612, 4): "#CFD8DC",
    (612, 5): "#586C77",
    (612, 6): "#FE857C",
    (612, 7): "#FF80AB",
    (612, 8): "#EA80FC",
    (612, 9): "#B485F8",
    (612, 10): "#9296F1",
    (612, 11): "#8AA5EE",
    (612, 12): "#96B2D2",
    (612, 13): "#8EEAEA",
    (612, 14): "#A8FBE8",
    (612, 15): "#BAEFC5",
    
    # ID:613（16组）
    (613, 0): "#2E7D32",
    (613, 1): "#F4FF81",
    (613, 2): "#FFFF8D",
    (613, 3): "#9CCC65",
    (613, 5): "#FF9E80",
    (613, 6): "#90A4AE",
    (613, 7): "#3F454D",
    (613, 8): "#FBD4D7",
    (613, 9): "#F9C0CB",
    (613, 10): "#EFD2F0",
    (613, 11): "#E8DAF0",
    (613, 12): "#D7E0F1",
    (613, 13): "#D8DDED",
    (613, 14): "#D9F3FF",
    (613, 15): "#D3E8EB",
    
    # ID:614（16组）
    (614, 0): "#C62828",
    (614, 1): "#DEE8D6",
    (614, 2): "#EDF9DF",
    (614, 3): "#F7F0D3",
    (614, 4): "#FFFCDD",
    (614, 5): "#FFF0D3",
    (614, 6): "#FFEBD5",
    (614, 7): "#FFDFDD",
    (614, 8): "#7A8E9B",
    (614, 9): "#293138",
    (614, 10): "#FFCDD2",
    (614, 11): "#F8BBD0",
    (614, 12): "#E1BEE7",
    (614, 13): "#D1C4E9",
    (614, 14): "#C5CAE9",
    (614, 15): "#BBDEFB",
    
    # ID:615（16组）
    (615, 0): "#627B8A",
    (615, 1): "#B2EBF2",
    (615, 2): "#B2DFDB",
    (615, 3): "#C8E6C9",
    (615, 4): "#DCEDC8",
    (615, 5): "#F0F4C3",
    (615, 6): "#FFF9C4",
    (615, 7): "#FFECB3",
    (615, 8): "#FFE0B2",
    (615, 9): "#FFCCBC",
    (615, 10): "#000000",
    (615, 11): "#EF9A9A",
    
    # 特殊ID（19开头，8组）
    (1900, 0): "#FF6E40",
    (1901, 0): "#FECB7D",
    (1902, 0): "#6400E7",
    (1903, 0): "#C6FF00",
    (1904, 0): "#FFF176",
    (1905, 0): "#FFCC80",
    (1906, 0): "#B39DDB",
    (1907, 0): "#AEEA00",
    (1908, 0): "#355EF1",
    (1909, 0): "#795548",
    (1910, 0): "#AC01F8",
    (1911, 0): "#00C853"
}

# ===================== 颜色转换工具函数 =====================
def hex_to_rgba(hex_color, alpha=1.0, saturation=1.5):
    """
    将十六进制颜色代码转换为Blender可用的RGBA值（0-1范围）
    :param hex_color: 十六进制颜色码（如#FFCDD2）
    :param alpha: 透明度（0-1）
    :param saturation: 饱和度倍数（>1提升鲜艳度，<1降低，推荐1.2~2.0）
    :return: (r, g, b, alpha)
    """
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 6:
        # 转换为0-1的RGB值
        r = int(hex_color[0:2], 16) / 255.0
        g = int(hex_color[2:4], 16) / 255.0
        b = int(hex_color[4:6], 16) / 255.0
        
        # 提升饱和度（限制在0-1范围内，避免颜色溢出）
        r = min(r * saturation, 10.0)
        g = min(g * saturation, 10.0)
        b = min(b * saturation, 10.0)
        
        return (r, g, b, alpha)
    return (1.0, 1.0, 1.0, alpha)  # 默认白色

# ===================== 上色水泥块判断与网格创建函数 =====================
def is_colored_cement_block(block_name):
    """判断是否为上色水泥块（根据名称）"""
    return "上色水泥" in block_name

def create_colored_cement_mesh(block_name, id_value, data_value, context):
    """创建带颜色的上色水泥块网格（修复：使用RGB色轮节点，移除多余Mapping连接）"""
    cache_key = (block_name, id_value, data_value)
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    
    # 1. 复用原脚本的立方体创建逻辑（不变）
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    cube_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    
    # 2. 应用独立UV（和原脚本的立方体保持一致，不变）
    cube_mesh = apply_cube_uv(cube_mesh)
    
    # 3. 创建颜色材质（核心修复：使用RGB色轮，简化节点树）
    hex_color = COLORED_CEMENT_COLOR_MAP.get((id_value, data_value), "#FFFFFF")
    rgba_color = hex_to_rgba(hex_color)
    mat_name = f"上色水泥块材质_{block_name}_{id_value}_{data_value}"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    
    # 清空默认节点，重建极简节点树（仅保留「RGB色轮→Principled BSDF→输出」）
    nodes.clear()
    output_node = nodes.new(type='ShaderNodeOutputMaterial')  # 输出节点
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')    #  Principled BSDF节点
    rgb_node = nodes.new(type='ShaderNodeRGB')                # RGB色轮节点（关键新增）
    
    # 调整节点位置（方便可视化编辑）
    rgb_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    
    # 连接节点（RGB色轮直接连BSDF，无多余节点）
    links.new(rgb_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    
    # 设置RGB色轮颜色和水泥质感参数
    rgb_node.outputs['Color'].default_value = rgba_color  # 直接绑定颜色
    bsdf_node.inputs['Roughness'].default_value = 0.3     # 水泥粗糙感
    bsdf_node.inputs['Specular'].default_value = 0.1      # 低反光（符合水泥材质）
    bsdf_node.inputs['Transmission'].default_value = 0.2  # 投射 可根据需求调整
    
    # 4. 绑定材质并缓存（不变）
    cube_mesh.materials.clear()
    cube_mesh.materials.append(mat)
    cube_mesh.name = f"上色水泥块网格_{block_name}_{id_value}_{data_value}"
    mesh_cache[cache_key] = cube_mesh
    return cube_mesh

# ===================== 玻璃块判断与网格创建函数（最终版：颜色映射+贴图+半透明+RGB转换） =====================
def is_glass_block(block_name):
    """判断是否为玻璃块（根据名称）"""
    return "玻璃" in block_name

def create_glass_mesh(block_name, id_value, data_value, context):
    """创建带颜色映射+贴图+半透明的玻璃块网格（含RGB转换）"""
    cache_key = (block_name, id_value, data_value)
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    
    # 1. 创建立方体网格并应用独立UV（和普通方块一致）
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    cube_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    cube_mesh = apply_cube_uv(cube_mesh)
    
    # 2. 从映射表获取颜色并转换为RGBA（含透明度）
    hex_color = GLASS_COLOR_MAP.get((id_value, data_value), "#FFFFFF")  # 无映射则默认白色
    rgba_color = hex_to_rgba(hex_color, alpha=0.4)  # 玻璃基础透明度0.4
    
    # 3. 创建玻璃材质（贴图+颜色映射+半透明+RGB转换）
    mat_name = f"玻璃块材质_{block_name}_{id_value}_{data_value}"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    # 核心节点树：UV → 贴图 → 颜色混合（贴图+RGB色轮）→ 半透明BSDF → 输出
    # 1) 创建节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')       # 输出
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')          # 玻璃着色器
    tex_node = nodes.new(type='ShaderNodeTexImage')                 # 玻璃贴图
    uv_node = nodes.new(type='ShaderNodeUVMap')                     # UV映射
    mapping_node = nodes.new(type='ShaderNodeMapping')              # UV映射调整
    rgb_node = nodes.new(type='ShaderNodeRGB')                      # RGB色轮（颜色映射转换）
    mix_node = nodes.new(type='ShaderNodeMixRGB')                   # 贴图和颜色混合
    
    # 2) 调整节点位置（方便可视化）
    uv_node.location = (-1000, 0)
    mapping_node.location = (-800, 0)
    tex_node.location = (-600, 100)
    rgb_node.location = (-600, -100)
    mix_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    
    # 3) 连接节点（核心：贴图和颜色混合，保留RGB转换）
    # UV → 贴图
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    # 贴图 + RGB色轮 → 混合节点（贴图为主，颜色为色调）
    links.new(tex_node.outputs['Color'], mix_node.inputs['Color1'])
    links.new(rgb_node.outputs['Color'], mix_node.inputs['Color2'])
    mix_node.inputs['Fac'].default_value = 0.3  # 颜色占比30%，贴图占比70%
    # 混合结果 → 玻璃着色器
    links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    
    # 4) 配置玻璃材质参数（半透明+高光+折射率）
    rgb_node.outputs['Color'].default_value = rgba_color  # RGB色轮绑定映射颜色
    bsdf_node.inputs['Roughness'].default_value = 0.0     # 玻璃光滑
    bsdf_node.inputs['Specular'].default_value = 0.8      # 玻璃高光
    bsdf_node.inputs['Transmission'].default_value = 0.9   # 高透光（半透明核心）
    bsdf_node.inputs['Alpha'].default_value = rgba_color[3]  # 绑定透明度
    bsdf_node.inputs['IOR'].default_value = 1.5           # 玻璃折射率
    
    # 5) 加载玻璃贴图（和普通方块同目录）
    paths = get_minix_paths(context)
    tex_path = os.path.join(paths["texture"], f"{block_name}.png")
    if os.path.exists(tex_path):
        try:
            img = bpy.data.images.load(tex_path)
            img.colorspace_settings.name = 'sRGB'
            tex_node.image = img
            print(f"✅ 玻璃贴图加载成功 → {block_name}")
        except Exception as e:
            print(f"⚠️ 玻璃贴图加载失败：{block_name} → {e}")
            # 无贴图时直接用RGB颜色作为基础色
            links.remove(links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color']))
            links.new(rgb_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    else:
        print(f"⚠️ 玻璃贴图缺失：{tex_path}，仅显示颜色映射")
        links.remove(links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color']))
        links.new(rgb_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    
    # 4. 配置贴图（独立UV，关闭重复）
    setup_repeat_texture(mat)
    
    # 5. 绑定材质并缓存
    cube_mesh.materials.clear()
    cube_mesh.materials.append(mat)
    cube_mesh.name = f"玻璃块网格_{block_name}_{id_value}_{data_value}"
    mesh_cache[cache_key] = cube_mesh
    return cube_mesh

# ===================== 棉花块判断与网格创建函数（复用玻璃块逻辑，适配棉花质感） =====================
def is_cotton_block(block_name):
    """判断是否为棉花块（根据名称）"""
    return "棉花" in block_name

def create_cotton_mesh(block_name, id_value, data_value, context):
    """创建带颜色映射+贴图+蓬松质感的棉花块网格（修复颜色过淡）"""
    cache_key = (block_name, id_value, data_value)
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    
    # 1. 创建立方体网格并应用独立UV（和普通方块一致）
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    cube_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    cube_mesh = apply_cube_uv(cube_mesh)
    
    # 2. 调整颜色饱和度（从1.2提升到2.0，颜色更鲜艳）
    hex_color = COTTON_COLOR_MAP.get((id_value, data_value), "#FFFFFF")
    rgba_color = hex_to_rgba(hex_color, alpha=1.0, saturation=2.0)  # 🔴 饱和度提升到2.0
    
    # 3. 创建棉花材质（调整颜色混合比例+次表面参数）
    mat_name = f"棉花块材质_{block_name}_{id_value}_{data_value}"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    # 核心节点树：UV → 贴图 → 颜色混合（贴图+RGB色轮）→ 蓬松BSDF → 输出
    output_node = nodes.new(type='ShaderNodeOutputMaterial')       
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')          
    tex_node = nodes.new(type='ShaderNodeTexImage')                 
    uv_node = nodes.new(type='ShaderNodeUVMap')                     
    mapping_node = nodes.new(type='ShaderNodeMapping')              
    rgb_node = nodes.new(type='ShaderNodeRGB')                      
    mix_node = nodes.new(type='ShaderNodeMixRGB')                   
    
    # 调整节点位置
    uv_node.location = (-1000, 0)
    mapping_node.location = (-800, 0)
    tex_node.location = (-600, 100)
    rgb_node.location = (-600, -100)
    mix_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    
    # 连接节点（调整颜色混合比例）
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], mix_node.inputs['Color1'])
    links.new(rgb_node.outputs['Color'], mix_node.inputs['Color2'])
    mix_node.inputs['Fac'].default_value = 1  # 🔴 颜色占比60%，贴图占40%（原20%）
    links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    
    # 配置棉花材质参数（降低次表面散射，减少颜色稀释）
    rgb_node.outputs['Color'].default_value = rgba_color
    bsdf_node.inputs['Roughness'].default_value = 0.9     # 保留蓬松感
    bsdf_node.inputs['Specular'].default_value = 0.1      # 低高光不变
    bsdf_node.inputs['Transmission'].default_value = 0.0  # 不透光不变
    bsdf_node.inputs['Alpha'].default_value = rgba_color[3]
    bsdf_node.inputs['Subsurface'].default_value = 0.1    # 🔴 次表面散射从0.5降到0.1
    bsdf_node.inputs['Subsurface Radius'].default_value = (0.05, 0.05, 0.05)  # 🔴 缩小次表面半径
    
    # 5) 加载棉花贴图
    paths = get_minix_paths(context)
    tex_path = os.path.join(paths["texture"], f"{block_name}.png")
    if os.path.exists(tex_path):
        try:
            img = bpy.data.images.load(tex_path)
            img.colorspace_settings.name = 'sRGB'
            tex_node.image = img
            print(f"✅ 棉花贴图加载成功 → {block_name}")
        except Exception as e:
            print(f"⚠️ 棉花贴图加载失败：{block_name} → {e}")
            links.remove(links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color']))
            links.new(rgb_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    else:
        print(f"⚠️ 棉花贴图缺失：{tex_path}，仅显示颜色映射")
        links.remove(links.new(mix_node.outputs['Color'], bsdf_node.inputs['Base Color']))
        links.new(rgb_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    
    # 4. 配置贴图（独立UV，关闭重复）
    setup_repeat_texture(mat)
    
    # 5. 绑定材质并缓存
    cube_mesh.materials.clear()
    cube_mesh.materials.append(mat)
    cube_mesh.name = f"棉花块网格_{block_name}_{id_value}_{data_value}"
    mesh_cache[cache_key] = cube_mesh
    return cube_mesh
# ===================== 插件偏好设置（持久化存储路径） =====================
class MINIX_AddonPreferences(AddonPreferences):
    bl_idname = __name__  # 关联当前插件
    # 持久化存储MINIX根目录
    minix_root_path: StringProperty(
        name="MINIX根目录",
        description="选择你的MINIX总文件夹路径（重启Blender后会保留）",
        default="",
        subtype='DIR_PATH',
        update=lambda self, context: self.update_csv_path(context)  # 根目录变化时更新CSV路径
    )
    # 持久化存储CSV文件夹路径（自动从根目录推导，也可手动修改）
    csv_folder_path: StringProperty(
        name="CSV文件夹路径",
        description="CSV文件所在的文件夹路径（重启Blender后会保留）",
        default="",
        subtype='DIR_PATH'
    )
    def update_csv_path(self, context):
        """当MINIX根目录变化时，自动更新CSV文件夹路径"""
        if self.minix_root_path and os.path.exists(self.minix_root_path):
            csv_path = os.path.join(self.minix_root_path, "csv")
            if os.path.exists(csv_path):
                self.csv_folder_path = csv_path
    def draw(self, context):
        """在插件偏好设置中显示路径配置"""
        layout = self.layout
        layout.prop(self, "minix_root_path")
        layout.prop(self, "csv_folder_path")

# ===================== 自定义属性组（兼容原有逻辑，优先使用偏好设置） =====================
class MINIX_Settings(PropertyGroup):
    # 保留该属性以兼容原有UI，实际使用时优先读取插件偏好设置
    minix_root_path: StringProperty(
        name="MINIX根目录",
        description="选择你的MINIX总文件夹路径",
        default="",
        subtype='DIR_PATH'
    )

# ===================== 全局变量 =====================
mesh_cache = {}  # 缓存「网格+预计算UV」
grouped_block_data = defaultdict(list)  # 按类型分组存储方块数据

# ===================== 路径工具函数（优先使用偏好设置的路径） =====================
def get_addon_preferences(context):
    """获取插件的偏好设置（存储持久化路径）"""
    return context.preferences.addons.get(__name__, None).preferences

def get_minix_paths(context):
    """根据插件偏好设置的路径，获取所有子文件夹路径"""
    prefs = get_addon_preferences(context)
    # 优先使用偏好设置中的根目录，其次使用场景属性中的目录，最后兜底
    minix_root = prefs.minix_root_path or context.scene.minix_settings.minix_root_path
    if not minix_root or not os.path.exists(minix_root):
        # 兜底：使用当前脚本所在目录的上级目录
        minix_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # 拼接子文件夹路径
    csv_folder = prefs.csv_folder_path or os.path.join(minix_root, "csv")
    texture_folder = os.path.join(minix_root, "贴图")
    stair_subfolder = os.path.join(texture_folder, "楼梯")
    slab_subfolder = os.path.join(texture_folder, "薄板")
    vertical_slab_subfolder = os.path.join(texture_folder, "竖薄板")
    
    return {
        "root": minix_root,
        "csv": csv_folder,
        "texture": texture_folder,
        "stair": stair_subfolder,
        "slab": slab_subfolder,
        "vertical_slab": vertical_slab_subfolder
    }

def get_stair_tex_path(block_name, context):
    paths = get_minix_paths(context)
    return os.path.join(paths["stair"], f"{block_name}.png")

def get_slab_tex_path(block_name, context):
    paths = get_minix_paths(context)
    return os.path.join(paths["slab"], f"{block_name}.png")

def get_vertical_slab_tex_path(block_name, context):
    paths = get_minix_paths(context)
    return os.path.join(paths["vertical_slab"], f"{block_name}.png")

def get_vertical_panel_tex_path(block_name, context):
    slab_block_name = block_name.replace("竖板", "竖薄板")
    return get_vertical_slab_tex_path(slab_block_name, context)

# ===================== 性能优化：工具函数（独立UV版） =====================
def clean_up_unused_data():
    """【性能优化】清理Blender中未使用的网格、材质、图片数据，释放内存"""
    mesh_count = 0
    for mesh in bpy.data.meshes:
        if not mesh.users:
            bpy.data.meshes.remove(mesh)
            mesh_count += 1
    mat_count = 0
    for mat in bpy.data.materials:
        if not mat.users:
            bpy.data.materials.remove(mat)
            mat_count += 1
    img_count = 0
    for img in bpy.data.images:
        if not img.users:
            bpy.data.images.remove(img)
            img_count += 1
    print(f"✅ 已清理冗余数据：网格{mesh_count}个 | 材质{mat_count}个 | 图片{img_count}个")

def calculate_block_uv(vert_co_local, normal_key):
    """
    基于小方块的局部坐标（0~1）计算UV，确保每个方块对应一张贴图
    :param vert_co_local: 小方块的局部顶点坐标（范围：0~1）
    :param normal_key: 面的法向量键（如(1,0,0)表示X+方向）
    :return: (u, v) UV坐标（范围：0~1）
    """
    nx, ny, nz = normal_key
    # 局部坐标归一化到0~1（对应贴图的完整范围）
    co = vert_co_local
    if nx == 1:  # 右侧（X+）
        u = 1 - co.y  # 反转Y轴，匹配贴图方向
        v = 1 - co.z
    elif nx == -1:  # 左侧（X-）
        u = co.y
        v = 1 - co.z
    elif ny == 1:  # 前侧（Y+）
        u = co.x
        v = 1 - co.z
    elif ny == -1:  # 后侧（Y-）
        u = 1 - co.x
        v = 1 - co.z
    elif nz == 1:  # 上侧（Z+）
        u = co.x
        v = co.y
    elif nz == -1:  # 下侧（Z-）
        u = co.x
        v = 1 - co.y
    else:
        u = co.x
        v = co.y
    # 确保UV在0~1之间，不重复（每个方块对应一张贴图）
    return (u, v)

def apply_cube_uv(mesh, block_size=BLOCK_SIZE):
    """
    为单个方块网格添加UV（基于局部坐标），每个方块对应一张贴图
    :param mesh: 单个方块的网格
    :param block_size: 方块尺寸（默认1）
    :return: 带UV的网格
    """
    bm = bmesh.new()
    bm.from_mesh(mesh)
    # 确保UV层存在
    if not bm.loops.layers.uv:
        bm.loops.layers.uv.new()
    uv_layer = bm.loops.layers.uv.active
    # 按面的法向量分组
    face_groups = {}
    for face in bm.faces:
        normal = face.normal.normalized()
        normal_key = (round(normal.x), round(normal.y), round(normal.z))
        if normal_key not in face_groups:
            face_groups[normal_key] = []
        face_groups[normal_key].append(face)
    # 计算每个顶点的局部坐标（相对于方块中心，范围：0~1）
    for normal_key, faces in face_groups.items():
        for face in faces:
            for loop in face.loops:
                vert = loop.vert
                # 转换为局部坐标：将顶点坐标从[-0.5, 0.5]（Blender立方体默认）转换为[0, 1]
                co_local = (vert.co / block_size) + Vector((0.5, 0.5, 0.5))
                # 计算UV（每个方块的UV都是0~1，对应一张贴图）
                u, v = calculate_block_uv(co_local, normal_key)
                loop[uv_layer].uv = (u, v)
    # 写入网格并清理
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    return mesh

def setup_repeat_texture(mat, repeat_times=1.0):
    """
    为材质设置贴图（关闭自动重复，确保每个方块对应一张贴图）
    :param mat: 目标材质
    :param repeat_times: 保留参数，实际不再使用
    """
    if not mat.use_nodes:
        mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    # 查找或创建必要节点
    # 1. 查找图片纹理节点
    tex_node = None
    for n in nodes:
        if n.type == 'ShaderNodeTexImage':
            tex_node = n
            break
    if not tex_node:
        return
    # 关键：关闭图片的自动重复（Blender默认是重复，这里改为裁剪）
    if tex_node.image:
        tex_node.image.extension = 'EXTEND'  # 裁剪：超出0~1的UV显示边缘像素（我们的UV都是0~1，所以刚好显示整张贴图）
    # 查找或创建Mapping节点（仅用于微调，不再依赖缩放实现重复）
    mapping_node = None
    for n in nodes:
        if n.type == 'ShaderNodeMapping':
            mapping_node = n
            break
    if not mapping_node:
        mapping_node = nodes.new(type='ShaderNodeMapping')
        mapping_node.location = (-600, 0)
        # 连接UVMap
        uv_node = None
        for n in nodes:
            if n.type == 'ShaderNodeUVMap':
                uv_node = n
                break
        if not uv_node:
            uv_node = nodes.new(type='ShaderNodeUVMap')
            uv_node.location = (-800, 0)
        links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    # 重置缩放为1（每个方块对应一张贴图）
    mapping_node.inputs['Scale'].default_value = (1.0, 1.0, 1.0)
    mapping_node.inputs['Location'].default_value = (0, 0, 0)
    # 确保Mapping节点连接到图片纹理节点
    if not any(link.from_node == mapping_node for link in links if link.to_node == tex_node):
        links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])

def merge_mesh_instances(prototype_mesh, instances_data):
    """
    合并网格时，为每个小方块保留局部UV（核心：不再依赖全局坐标计算UV）
    :param prototype_mesh: 单个方块的原型网格（已带局部UV）
    :param instances_data: 实例数据列表 [(location, rotation_euler), ...]
    :return: 合并后的网格（每个小方块UV独立）
    """
    if not instances_data:
        return None
    # 创建新的网格用于合并
    merged_mesh = bpy.data.meshes.new(f"{prototype_mesh.name}_merged")
    # 收集所有顶点、面、UV数据
    all_verts = []
    all_faces = []
    all_uvs = []
    vert_offset = 0
    # 遍历每个实例（每个小方块）
    for loc, rot_euler in instances_data:
        # 复制原型网格的顶点，并应用旋转和位移
        proto_verts = [v.co for v in prototype_mesh.vertices]
        rot_matrix = rot_euler.to_matrix()
        translated_verts = [rot_matrix @ v + loc for v in proto_verts]
        all_verts.extend(translated_verts)
        # 复制原型网格的面，更新顶点索引
        proto_faces = [f.vertices for f in prototype_mesh.polygons]
        translated_faces = [[v + vert_offset for v in f] for f in proto_faces]
        all_faces.extend(translated_faces)
        # 复制原型网格的UV（关键：直接复用局部UV，每个小方块的UV都是0~1）
        if prototype_mesh.uv_layers:
            uv_layer = prototype_mesh.uv_layers.active
            proto_uvs = [uv.uv for uv in uv_layer.data]
            all_uvs.extend(proto_uvs)
        vert_offset += len(proto_verts)
    # 将数据写入合并后的网格
    merged_mesh.from_pydata(all_verts, [], all_faces)
    # 写入UV数据
    if all_uvs:
        if not merged_mesh.uv_layers:
            merged_mesh.uv_layers.new(name="UVMap")
        uv_layer = merged_mesh.uv_layers.active
        for i, uv in enumerate(all_uvs):
            uv_layer.data[i].uv = uv
    # 继承材质
    if prototype_mesh.materials:
        merged_mesh.materials.append(prototype_mesh.materials[0])
    merged_mesh.update()
    return merged_mesh

def switch_preview_mode(mode='fast'):
    """保留：快速预览/材质预览切换，不影响核心性能"""
    if mode == 'fast':
        bpy.context.scene.render.engine = 'BLENDER_WORKBENCH'
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'WIREFRAME'
                        break
                break
    else:
        bpy.context.scene.render.engine = 'CYCLES'
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        space.shading.type = 'SOLID'
                        space.shading.color_type = 'MATERIAL'
                        break
                break

# ===================== 类型判断工具函数 =====================
def is_stair_block(block_name):
    return "楼梯" in block_name

def is_slab_block(block_name):
    return "薄板" in block_name and "竖薄板" not in block_name

def is_vertical_slab_block(block_name):
    return "竖薄板" in block_name

def is_vertical_panel_block(block_name):
    return "竖板" in block_name and "竖薄板" not in block_name

# ===================== 网格创建函数（独立UV版+缓存） =====================
def create_slab_mesh(block_name, data_value, context):
    cache_key = f"{block_name}_{data_value}"
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    if data_value not in SLAB_RULES:
        print(f"⚠️ 未知薄板data值：{data_value}，使用立方体")
        mesh = create_cube_mesh_with_texture(block_name, context)
        mesh_cache[cache_key] = mesh
        return mesh
    placement, height = SLAB_RULES[data_value]
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    slab_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    bm = bmesh.new()
    bm.from_mesh(slab_mesh)
    min_z = float('inf')
    max_z = -float('inf')
    for vert in bm.verts:
        min_z = min(min_z, vert.co.z)
        max_z = max(max_z, vert.co.z)
    if placement == "bottom":
        target_max_z = min_z + height
        for vert in bm.verts:
            if vert.co.z > min_z + 0.01:
                vert.co.z = min_z + (vert.co.z - min_z) * (height / (max_z - min_z))
    elif placement == "top":
        target_min_z = max_z - height
        for vert in bm.verts:
            if vert.co.z < max_z - 0.01:
                vert.co.z = target_min_z + (vert.co.z - min_z) * (height / (max_z - min_z))
    bm.to_mesh(slab_mesh)
    bm.free()
    slab_mesh = apply_cube_uv(slab_mesh)  # 使用独立UV函数
    tex_path = get_slab_tex_path(block_name, context)
    if not os.path.exists(tex_path):
        print(f"⚠️ 薄板贴图缺失：{tex_path}，使用立方体")
        mesh = create_cube_mesh_with_texture(block_name, context)
        mesh_cache[cache_key] = mesh
        return mesh
    slab_mesh.name = f"薄板网格_{block_name}_{data_value}"
    mat = bpy.data.materials.new(name=f"薄板材质_{block_name}_{data_value}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    # 重新创建所有必要节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
    tex_node = nodes.new(type='ShaderNodeTexImage')
    uv_node = nodes.new(type='ShaderNodeUVMap')
    mapping_node = nodes.new(type='ShaderNodeMapping')
    # 调整节点位置
    uv_node.location = (-800, 0)
    mapping_node.location = (-600, 0)
    tex_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    # 连接节点
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    try:
        img = bpy.data.images.load(tex_path)
        img.name = f"薄板贴图_{block_name}"
        img.colorspace_settings.name = 'sRGB'
        tex_node.image = img
        print(f"✅ 薄板贴图加载成功 → {block_name}：{os.path.basename(tex_path)}")
    except Exception as e:
        print(f"⚠️ 薄板贴图加载失败：{block_name} → {e}")
        bsdf_node.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)
    # 配置贴图（每个方块独立显示）
    setup_repeat_texture(mat)
    slab_mesh.materials.clear()
    slab_mesh.materials.append(mat)
    mesh_cache[cache_key] = slab_mesh
    return slab_mesh

def create_vertical_slab_mesh(block_name, data_value, context):
    cache_key = f"{block_name}_{data_value}"
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    if data_value not in VERTICAL_SLAB_RULES:
        print(f"⚠️ 未知竖薄板data值：{data_value}，使用立方体")
        mesh = create_cube_mesh_with_texture(block_name, context)
        mesh_cache[cache_key] = mesh
        return mesh
    direction, fill_ratio = VERTICAL_SLAB_RULES[data_value]
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    vert_slab_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    bm = bmesh.new()
    bm.from_mesh(vert_slab_mesh)
    EAST_BOUND = 0.5
    WEST_BOUND = -0.5
    NORTH_BOUND = 0.5
    SOUTH_BOUND = -0.5
    if direction == "east":
        target_min_x = EAST_BOUND - fill_ratio * BLOCK_SIZE
        for vert in bm.verts:
            if vert.co.x < target_min_x:
                vert.co.x = target_min_x
    elif direction == "west":
        target_max_x = WEST_BOUND + fill_ratio * BLOCK_SIZE
        for vert in bm.verts:
            if vert.co.x > target_max_x:
                vert.co.x = target_max_x
    elif direction == "north":
        target_min_y = NORTH_BOUND - fill_ratio * BLOCK_SIZE
        for vert in bm.verts:
            if vert.co.y < target_min_y:
                vert.co.y = target_min_y
    elif direction == "south":
        target_max_y = SOUTH_BOUND + fill_ratio * BLOCK_SIZE
        for vert in bm.verts:
            if vert.co.y > target_max_y:
                vert.co.y = target_max_y
    bm.to_mesh(vert_slab_mesh)
    bm.free()
    vert_slab_mesh = apply_cube_uv(vert_slab_mesh)  # 使用独立UV函数
    tex_path = get_vertical_slab_tex_path(block_name, context)
    if not os.path.exists(tex_path):
        print(f"⚠️ 竖薄板贴图缺失：{tex_path}，使用立方体")
        mesh = create_cube_mesh_with_texture(block_name, context)
        mesh_cache[cache_key] = mesh
        return mesh
    vert_slab_mesh.name = f"竖薄板网格_{block_name}_{data_value}"
    mat = bpy.data.materials.new(name=f"竖薄板材质_{block_name}_{data_value}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    # 重新创建所有必要节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
    tex_node = nodes.new(type='ShaderNodeTexImage')
    uv_node = nodes.new(type='ShaderNodeUVMap')
    mapping_node = nodes.new(type='ShaderNodeMapping')
    # 调整节点位置
    uv_node.location = (-800, 0)
    mapping_node.location = (-600, 0)
    tex_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    # 连接节点
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    try:
        img = bpy.data.images.load(tex_path)
        img.name = f"竖薄板贴图_{block_name}"
        img.colorspace_settings.name = 'sRGB'
        tex_node.image = img
        print(f"✅ 竖薄板贴图加载成功 → {block_name}：{os.path.basename(tex_path)}")
    except Exception as e:
        print(f"⚠️ 竖薄板贴图加载失败：{block_name} → {e}")
        bsdf_node.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)
    # 配置贴图（每个方块独立显示）
    setup_repeat_texture(mat)
    vert_slab_mesh.materials.clear()
    vert_slab_mesh.materials.append(mat)
    mesh_cache[cache_key] = vert_slab_mesh
    return vert_slab_mesh

def create_vertical_panel_mesh(block_name, data_value, context):
    cache_key = f"{block_name}_{data_value}"
    if cache_key in mesh_cache:
        return mesh_cache[cache_key]
    if data_value in VERTICAL_PANEL_TO_SLAB_DATA_MAP:
        mapped_data = VERTICAL_PANEL_TO_SLAB_DATA_MAP[data_value]
    else:
        print(f"⚠️ 未知竖板data值：{data_value}，默认映射为东向0.5")
        mapped_data = 4
    slab_block_name = block_name.replace("竖板", "竖薄板")
    cache_key_slab = f"{slab_block_name}_{mapped_data}"
    if cache_key_slab in mesh_cache:
        mesh = mesh_cache[cache_key_slab]
    else:
        mesh = create_vertical_slab_mesh(slab_block_name, mapped_data, context)
    mat = bpy.data.materials.new(name=f"竖板材质_{block_name}_{data_value}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    # 重新创建所有必要节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
    tex_node = nodes.new(type='ShaderNodeTexImage')
    uv_node = nodes.new(type='ShaderNodeUVMap')
    mapping_node = nodes.new(type='ShaderNodeMapping')
    # 调整节点位置
    uv_node.location = (-800, 0)
    mapping_node.location = (-600, 0)
    tex_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    # 连接节点
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    tex_path = get_vertical_panel_tex_path(block_name, context)
    try:
        img = bpy.data.images.load(tex_path)
        img.name = f"竖板贴图_{block_name}"
        img.colorspace_settings.name = 'sRGB'
        tex_node.image = img
        print(f"✅ 竖板贴图加载成功 → {block_name}：{os.path.basename(tex_path)}")
    except Exception as e:
        print(f"⚠️ 竖板贴图加载失败：{block_name} → {e}")
        bsdf_node.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)
    # 配置贴图（每个方块独立显示）
    setup_repeat_texture(mat)
    panel_mesh = mesh.copy()
    panel_mesh.name = f"竖板网格_{block_name}_{data_value}"
    panel_mesh.materials.clear()
    panel_mesh.materials.append(mat)
    mesh_cache[cache_key] = panel_mesh
    return panel_mesh

def load_common_stair_mesh_base(context):
    paths = get_minix_paths(context)
    stair_folder = paths["stair"]
    if not os.path.exists(stair_folder):
        raise Exception(f"楼梯文件夹不存在：{stair_folder}")
    STAIR_COMMON_OBJ = os.path.join(stair_folder, "楼梯.obj")
    if not os.path.exists(STAIR_COMMON_OBJ):
        raise Exception(f"楼梯OBJ不存在：{STAIR_COMMON_OBJ}")
    # 临时屏蔽OBJ导入的MTL警告
    import io
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.wm.obj_import(filepath=STAIR_COMMON_OBJ)
    finally:
        sys.stderr = old_stderr
    imported_objs = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
    if not imported_objs:
        raise Exception("未找到楼梯模型！")
    stair_obj = imported_objs[0]
    bm = bmesh.new()
    bm.from_mesh(stair_obj.data)
    rotate_x = math.radians(90)
    for vert in bm.verts:
        y = vert.co.y * math.cos(rotate_x) - vert.co.z * math.sin(rotate_x)
        z = vert.co.y * math.sin(rotate_x) + vert.co.z * math.cos(rotate_x)
        vert.co.y = y
        vert.co.z = z
    min_co = Vector((float('inf'), float('inf'), float('inf')))
    max_co = Vector((-float('inf'), -float('inf'), -float('inf')))
    for vert in bm.verts:
        min_co.x = min(min_co.x, vert.co.x)
        min_co.y = min(min_co.y, vert.co.y)
        min_co.z = min(min_co.z, vert.co.z)
        max_co.x = max(max_co.x, vert.co.x)
        max_co.y = max(max_co.y, vert.co.y)
        max_co.z = max(max_co.z, vert.co.z)
    size_x = max_co.x - min_co.x
    size_y = max_co.y - min_co.y
    size_z = max_co.z - min_co.z
    scale_x = BLOCK_SIZE / size_x if size_x != 0 else 1
    scale_y = BLOCK_SIZE / size_y if size_y != 0 else 1
    scale_z = BLOCK_SIZE / size_z if size_z != 0 else 1
    for vert in bm.verts:
        vert.co.x *= scale_x
        vert.co.y *= scale_y
        vert.co.z *= scale_z
    centroid = Vector((0, 0, 0))
    count = 0
    for vert in bm.verts:
        centroid += vert.co
        count += 1
    centroid /= count if count > 0 else 1
    offset = -centroid
    for vert in bm.verts:
        vert.co.x += offset.x
        vert.co.y += offset.y
        vert.co.z += offset.z
    bm.to_mesh(stair_obj.data)
    bm.free()
    stair_obj.data.update()
    stair_obj.data = apply_cube_uv(stair_obj.data)  # 使用独立UV函数
    base_mesh = stair_obj.data.copy()
    base_mesh.name = "楼梯基础网格_共用"
    bpy.data.objects.remove(stair_obj)
    return base_mesh

def create_stair_mesh_with_texture(block_name, base_stair_mesh, context):
    if block_name in mesh_cache:
        return mesh_cache[block_name]
    stair_mesh = base_stair_mesh.copy()
    stair_mesh.name = f"网格_{block_name}"
    mat = bpy.data.materials.new(name=f"材质_{block_name}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    # 重新创建所有必要节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
    tex_node = nodes.new(type='ShaderNodeTexImage')
    uv_node = nodes.new(type='ShaderNodeUVMap')
    mapping_node = nodes.new(type='ShaderNodeMapping')
    # 调整节点位置
    uv_node.location = (-800, 0)
    mapping_node.location = (-600, 0)
    tex_node.location = (-400, 0)
    bsdf_node.location = (-200, 0)
    output_node.location = (0, 0)
    # 连接节点
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    tex_path = get_stair_tex_path(block_name, context)
    if os.path.exists(tex_path):
        try:
            img = bpy.data.images.load(tex_path)
            img.name = f"贴图_{block_name}"
            img.colorspace_settings.name = 'sRGB'
            tex_node.image = img
            print(f"✅ 楼梯贴图加载成功 → {block_name}：{os.path.basename(tex_path)}")
        except Exception as e:
            print(f"⚠️ 楼梯贴图加载失败：{block_name} → {e}")
            bsdf_node.inputs['Base Color'].default_value = (0.6, 0.4, 0.2, 1)
    else:
        print(f"⚠️ 楼梯贴图缺失：{tex_path}")
        bsdf_node.inputs['Base Color'].default_value = (0.6, 0.4, 0.2, 1)
    # 配置贴图（每个方块独立显示）
    setup_repeat_texture(mat)
    stair_mesh.materials.clear()
    stair_mesh.materials.append(mat)
    mesh_cache[block_name] = stair_mesh
    return stair_mesh

def create_cube_mesh_with_texture(block_name, context):
    if block_name in mesh_cache:
        return mesh_cache[block_name]
    bpy.ops.mesh.primitive_cube_add(size=BLOCK_SIZE, location=(0, 0, 0))
    temp_cube = bpy.context.active_object
    cube_mesh = temp_cube.data.copy()
    bpy.data.objects.remove(temp_cube)
    cube_mesh = apply_cube_uv(cube_mesh)  # 使用独立UV函数
    mat = bpy.data.materials.new(name=f"材质_{block_name}")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    # 重新创建所有必要节点
    output_node = nodes.new(type='ShaderNodeOutputMaterial')
    bsdf_node = nodes.new(type='ShaderNodeBsdfPrincipled')
    tex_node = nodes.new(type='ShaderNodeTexImage')
    uv_node = nodes.new(type='ShaderNodeUVMap')
    mapping_node = nodes.new(type='ShaderNodeMapping')
    # 调整节点位置
    uv_node.location = (-800, 0)
    mapping_node.location = (-600, 0)
    tex_node.location = (-300, 0)
    bsdf_node.location = (0, 0)
    output_node.location = (300, 0)
    # 连接节点
    links.new(uv_node.outputs['UV'], mapping_node.inputs['Vector'])
    links.new(mapping_node.outputs['Vector'], tex_node.inputs['Vector'])
    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Base Color'])
    links.new(bsdf_node.outputs['BSDF'], output_node.inputs['Surface'])
    # 加载贴图
    paths = get_minix_paths(context)
    tex_path = os.path.join(paths["texture"], f"{block_name}.png")
    if os.path.exists(tex_path):
        try:
            img = bpy.data.images.load(tex_path)
            img.colorspace_settings.name = 'sRGB'
            tex_node.image = img
            print(f"✅ 方块贴图加载成功 → {block_name}")
        except Exception as e:
            print(f"⚠️ 方块贴图加载失败：{block_name} → {e}")
            bsdf_node.inputs['Base Color'].default_value = (0.8, 0.8, 0.8, 1)
    else:
        print(f"⚠️ 方块贴图缺失：{tex_path}")
        bsdf_node.inputs['Base Color'].default_value = (0.8, 0.8, 0.8, 1)
    # 配置贴图（每个方块独立显示）
    setup_repeat_texture(mat)
    cube_mesh.materials.clear()
    cube_mesh.materials.append(mat)
    mesh_cache[block_name] = cube_mesh
    return cube_mesh

def preload_all_resources(block_types, stair_types, slab_types, vertical_slab_types, vertical_panel_types, base_stair_mesh, context):
    print("\n📌 预加载网格+独立UV...")
    # 预加载普通方块（排除上色水泥块、玻璃块、棉花块，单独预加载）
    for block_name in block_types:
        if not is_stair_block(block_name) and not is_slab_block(block_name) and not is_vertical_slab_block(block_name) and not is_vertical_panel_block(block_name) and not is_colored_cement_block(block_name) and not is_glass_block(block_name) and not is_cotton_block(block_name):
            create_cube_mesh_with_texture(block_name, context)
    # 预加载楼梯
    for block_name in stair_types:
        if base_stair_mesh:
            create_stair_mesh_with_texture(block_name, base_stair_mesh, context)
    # 预加载普通薄板
    for block_name in slab_types:
        for data_val in SLAB_RULES.keys():
            create_slab_mesh(block_name, data_val, context)
    # 预加载竖薄板
    for block_name in vertical_slab_types:
        for data_val in VERTICAL_SLAB_RULES.keys():
            create_vertical_slab_mesh(block_name, data_val, context)
    # 预加载竖板
    for block_name in vertical_panel_types:
        for data_val in VERTICAL_PANEL_TO_SLAB_DATA_MAP.keys():
            create_vertical_panel_mesh(block_name, data_val, context)
    # 预加载上色水泥块、玻璃块、棉花块（需要ID和Data，这里仅初始化缓存结构）
    print(f"✅ 预加载完成 → 缓存网格总数：{len(mesh_cache)}")

# ===================== 核心导入逻辑（仅新增棉花块分支） =====================
class MINIX_OT_ImportBlocks(bpy.types.Operator, ImportHelper):
    """从CSV导入批量方块（独立UV版+上色水泥块+玻璃块+棉花块）"""
    bl_idname = "minix.import_blocks_uv"
    bl_label = "选择CSV文件"
    bl_options = {'REGISTER', 'UNDO'}
    # 过滤CSV文件
    filter_glob: StringProperty(
        default="*.csv",
        options={'HIDDEN'}
    )
    filename_ext = ".csv"

    def invoke(self, context, event):
        """重写invoke方法，打开文件选择窗口前设置默认路径为存储的CSV文件夹"""
        prefs = get_addon_preferences(context)
        # 如果有存储的CSV路径，设置为文件选择窗口的默认路径
        if prefs.csv_folder_path and os.path.exists(prefs.csv_folder_path):
            self.filepath = prefs.csv_folder_path  # 这里设置默认路径，窗口会直接跳到该文件夹
        # 调用默认的文件选择窗口
        return super().invoke(context, event)

    def execute(self, context):
        global grouped_block_data, mesh_cache
        # 重置全局变量
        grouped_block_data = defaultdict(list)
        mesh_cache = {}
        CSV_FILE_PATH = self.filepath
        # 保存当前选择的CSV文件所在的文件夹到偏好设置（方便下次直接跳转）
        prefs = get_addon_preferences(context)
        prefs.csv_folder_path = os.path.dirname(CSV_FILE_PATH)
        print("="*60)
        print("📌 MINIX方块导入工具（独立UV版+上色水泥块+玻璃块+棉花块）：每个方块独立贴图+批量合并")
        print("="*60)
        # 清理冗余数据
        clean_up_unused_data()
        switch_preview_mode(mode='fast')
        # 扫描CSV并分组
        block_types = set()
        stair_types = set()
        slab_types = set()
        vertical_slab_types = set()
        vertical_panel_types = set()
        try:
            with open(CSV_FILE_PATH, 'r', encoding='utf-8-sig') as f:
                csv_reader = csv.reader(f)
                next(csv_reader)  # 跳过表头
                for row in csv_reader:
                    if len(row) >= 6 and row[NAME_COL].strip():
                        block_name = row[NAME_COL].strip()
                        block_types.add(block_name)
                        try:
                            data_value = int(row[DATA_COL].strip()) if row[DATA_COL].strip() else 0
                            id_value = int(row[ID_COL].strip()) if row[ID_COL].strip() else 0  # 读取ID值
                        except:
                            data_value = 0
                            id_value = 0
                        # 坐标转换
                        mini_x = float(row[MINI_X_COL].strip())
                        mini_y = float(row[MINI_Y_COL].strip())
                        mini_z = float(row[MINI_Z_COL].strip())
                        blender_x = mini_x * BLOCK_SIZE
                        blender_y = -mini_z * BLOCK_SIZE
                        blender_z = mini_y * BLOCK_SIZE
                        loc = Vector((blender_x, blender_y, blender_z))
                        # 旋转计算（仅楼梯）
                        rot_euler = Euler((0, 0, 0), 'XYZ')
                        if is_stair_block(block_name) and data_value in STAIR_RULES:
                            is_inverted, rot_z = STAIR_RULES[data_value]
                            rot_z = Y_AXIS_FLIP_MAP[rot_z]
                            rot_x = math.pi if is_inverted else 0
                            rot_euler = Euler((rot_x, 0, rot_z), 'XYZ')
                        # 生成分组Key（新增棉花块分组）
                        if is_colored_cement_block(block_name):
                            group_key = (block_name, "colored_cement", id_value, data_value)
                        elif is_glass_block(block_name):
                            group_key = (block_name, "glass", id_value, data_value)
                        elif is_cotton_block(block_name):
                            group_key = (block_name, "cotton", id_value, data_value)
                        elif is_slab_block(block_name):
                            group_key = (block_name, "slab", data_value)
                            slab_types.add(block_name)
                        elif is_vertical_slab_block(block_name):
                            group_key = (block_name, "vertical_slab", data_value)
                            vertical_slab_types.add(block_name)
                        elif is_vertical_panel_block(block_name):
                            group_key = (block_name, "vertical_panel", data_value)
                            vertical_panel_types.add(block_name)
                        elif is_stair_block(block_name):
                            group_key = (block_name, "stair")
                            stair_types.add(block_name)
                        else:
                            group_key = (block_name, "cube")
                        grouped_block_data[group_key].append((loc, rot_euler))
            print(f"✅ CSV扫描完成 → 总类型：{len(block_types)}（楼梯：{len(stair_types)} | 薄板：{len(slab_types)} | 竖薄板：{len(vertical_slab_types)} | 竖板：{len(vertical_panel_types)} | 上色水泥块：{len([k for k in block_types if is_colored_cement_block(k)])} | 玻璃块：{len([k for k in block_types if is_glass_block(k)])} | 棉花块：{len([k for k in block_types if is_cotton_block(k)])}）")
        except Exception as e:
            self.report({'ERROR'}, f"CSV扫描失败：{str(e)}")
            return {'CANCELLED'}
        # 加载楼梯基础网格
        base_stair_mesh = None
        if stair_types:
            try:
                base_stair_mesh = load_common_stair_mesh_base(context)
                print(f"✅ 楼梯基础网格加载成功")
            except Exception as e:
                self.report({'WARNING'}, f"楼梯基础网格加载失败：{str(e)}，将使用立方体替代")
        # 预加载所有资源（含独立UV）
        preload_all_resources(block_types, stair_types, slab_types, vertical_slab_types, vertical_panel_types, base_stair_mesh, context)
        # 批量创建+合并网格
        print("\n📌 批量创建+合并网格（每个方块独立UV）...")
        created_objects = []
        for group_key, instances_data in grouped_block_data.items():
            block_name = group_key[0]
            type_tag = group_key[1]
            # 上色水泥块分支
            if type_tag == "colored_cement":
                id_value = group_key[2]
                data_value = group_key[3]
                try:
                    proto_mesh = create_colored_cement_mesh(block_name, id_value, data_value, context)
                except Exception as e:
                    print(f"⚠️ 上色水泥块网格创建失败：{block_name} → {e}，使用默认立方体")
                    proto_mesh = create_cube_mesh_with_texture(block_name, context)
            # 玻璃块分支
            elif type_tag == "glass":
                id_value = group_key[2]
                data_value = group_key[3]
                try:
                    proto_mesh = create_glass_mesh(block_name, id_value, data_value, context)
                except Exception as e:
                    print(f"⚠️ 玻璃块网格创建失败：{block_name} → {e}，使用默认立方体")
                    proto_mesh = create_cube_mesh_with_texture(block_name, context)
            # 棉花块分支（新增）
            elif type_tag == "cotton":
                id_value = group_key[2]
                data_value = group_key[3]
                try:
                    proto_mesh = create_cotton_mesh(block_name, id_value, data_value, context)
                except Exception as e:
                    print(f"⚠️ 棉花块网格创建失败：{block_name} → {e}，使用默认立方体")
                    proto_mesh = create_cube_mesh_with_texture(block_name, context)
            # 原有方块类型分支
            elif type_tag == "stair":
                if base_stair_mesh:
                    proto_mesh = create_stair_mesh_with_texture(block_name, base_stair_mesh, context)
                else:
                    proto_mesh = create_cube_mesh_with_texture(block_name, context)
            elif type_tag == "slab":
                data_value = group_key[2]
                proto_mesh = create_slab_mesh(block_name, data_value, context)
            elif type_tag == "vertical_slab":
                data_value = group_key[2]
                proto_mesh = create_vertical_slab_mesh(block_name, data_value, context)
            elif type_tag == "vertical_panel":
                data_value = group_key[2]
                proto_mesh = create_vertical_panel_mesh(block_name, data_value, context)
            else:  # cube
                proto_mesh = create_cube_mesh_with_texture(block_name, context)
            # 合并网格（保留独立UV）
            merged_mesh = merge_mesh_instances(proto_mesh, instances_data)
            if merged_mesh:
                obj = bpy.data.objects.new(f"合并_{block_name}", merged_mesh)
                bpy.context.collection.objects.link(obj)
                created_objects.append(obj)
        # 收尾工作
        switch_preview_mode(mode='material')
        clean_up_unused_data()
        # 选中结果
        if created_objects:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in created_objects:
                obj.select_set(True)
            context.view_layer.objects.active = created_objects[0]
        # 提示完成
        total_blocks = sum(len(v) for v in grouped_block_data.values())
        self.report({'INFO'}, f"✅ 导入完成：{len(created_objects)}个合并对象 | 总计{total_blocks}个方块（含上色水泥块{len([k for k in grouped_block_data if k[1] == 'colored_cement'])}种 | 玻璃块{len([k for k in grouped_block_data if k[1] == 'glass'])}种 | 棉花块{len([k for k in grouped_block_data if k[1] == 'cotton'])}种）")
        print("="*60)
        return {'FINISHED'}

# ===================== 面板UI（新增棉花块提示） =====================
class MINIX_PT_MainPanel(bpy.types.Panel):
    """MINIX工具主面板"""
    bl_label = "MINIX 方块导入工具（独立UV+上色水泥块+玻璃块+棉花块）"
    bl_idname = "MINIX_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'MINIX 工具'

    def draw(self, context):
        layout = self.layout
        prefs = get_addon_preferences(context)
        # 路径配置（持久化存储）
        layout.prop(prefs, "minix_root_path")
        layout.prop(prefs, "csv_folder_path")
        layout.separator()
        # 导入按钮
        layout.operator(MINIX_OT_ImportBlocks.bl_idname, text="选择CSV导入（含上色水泥块+玻璃块+棉花块）")
        # 提示信息
        layout.label(text="💡 上色水泥块将按ID+Data自动匹配颜色")
        layout.label(text="💡 玻璃块支持半透明材质+贴图+ID+Data颜色映射")
        layout.label(text="💡 棉花块支持蓬松质感+贴图+ID+Data颜色映射")
        layout.label(text="💡 每个方块独立显示贴图，无重复UV")

# ===================== 注册/注销（完整生命周期） =====================
classes = (
    MINIX_AddonPreferences,
    MINIX_Settings,
    MINIX_OT_ImportBlocks,
    MINIX_PT_MainPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.minix_settings = PointerProperty(type=MINIX_Settings)
    print("✅ MINIX方块导入工具（独立UV+上色水泥块+玻璃块+棉花块）已注册")

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.minix_settings
    print("❌ MINIX方块导入工具已注销")

if __name__ == "__main__":
    register()
import bpy
# 遍历场景内所有物体
for obj in bpy.context.scene.objects:
    if obj.data and hasattr(obj.data, "materials"):
        # 遍历物体的每个材质
        for mat in obj.data.materials:
            if mat.use_nodes:
                # 适配中英文原理化BSDF节点
                bsdf = mat.node_tree.nodes.get("Principled BSDF") or mat.node_tree.nodes.get("原理化BSDF")
                if bsdf:
                    bsdf.inputs['Roughness'].default_value = 1.0  # 粗糙度拉满
                    bsdf.inputs['Specular'].default_value = 0.0   # 高光归零
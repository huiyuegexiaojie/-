import csv
import os
import tkinter as tk
from tkinter import messagebox

def extract_and_merge_csv(log_file_path, output_csv_path, root):
    """
    从迷你世界日志文件中提取CSV数据并合并为完整CSV文件（修复中文乱码）
    :param log_file_path: 输入日志文件路径
    :param output_csv_path: 输出完整CSV文件路径
    :param root: tk主窗口对象（用于弹窗提示）
    """
    # 存储提取的有效数据（表头+所有数据行）
    valid_data = []
    # 标记是否已添加表头（避免重复）
    header_added = False
    # 表头标识（匹配日志中CSV数据的表头行）
    target_header = "方块X坐标,方块Y坐标,方块Z坐标,方块ID,方块附加Data,方块名称"

    # 1. 读取日志文件并提取有效数据
    try:
        with open(log_file_path, 'r', encoding='utf-8', errors='ignore') as log_file:
            for line_num, line in enumerate(log_file, 1):
                # 清理行首尾空白（去除换行符、空格等）
                clean_line = line.strip()

                # 跳过空行和无效行（分段标识、时间戳行等）
                if not clean_line:
                    continue
                # 过滤分段标识行（如"===== 数据分段1 ====="、"====================="）
                if clean_line.startswith("====") or clean_line.startswith("["):
                    continue

                # 处理表头行：仅保留第一个表头
                if clean_line == target_header:
                    if not header_added:
                        valid_data.append(clean_line.split(','))
                        header_added = True
                    continue  # 后续重复表头直接跳过

                # 处理数据行：判断是否以数字/负号（坐标）开头
                if clean_line[0] in ('0123456789-'):
                    # 按逗号分割数据（兼容CSV格式）
                    data_row = clean_line.split(',')
                    # 验证数据行完整性（需包含6列）
                    if len(data_row) == 6:
                        valid_data.append(data_row)
                    else:
                        # 弹窗提示无效行（可选：改为静默跳过，注释此行即可）
                        messagebox.showwarning(
                            "警告",
                            f"第{line_num}行数据列数不完整，已跳过：\n{clean_line}",
                            parent=root
                        )

        # 2. 检查是否提取到有效数据
        if not valid_data:
            messagebox.showerror("错误", "未从日志文件中提取到任何有效CSV数据，请检查日志格式！", parent=root)
            return

        # 3. 写入完整CSV文件（关键：用utf-8-sig编码解决中文乱码）
        with open(output_csv_path, 'w', newline='', encoding='utf-8-sig') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerows(valid_data)

        # 拼接成功提示信息
        success_info = (
            f"✅ 数据处理完成！\n"
            f"📊 提取到有效数据行数：{len(valid_data)}（含1个表头，{len(valid_data)-1}个数据行）\n"
            f"💾 输出文件路径：{os.path.abspath(output_csv_path)}\n"
            f"📂 输出文件所在文件夹：{os.path.dirname(os.path.abspath(output_csv_path))}"
        )
        messagebox.showinfo("成功", success_info, parent=root)

    except FileNotFoundError:
        messagebox.showerror("错误", f"输入日志文件不存在，请检查路径：\n{log_file_path}", parent=root)
    except PermissionError:
        messagebox.showerror("错误", "无权限访问文件，请关闭占用文件的程序后重试！", parent=root)
    except Exception as e:
        messagebox.showerror("错误", f"处理过程中出现错误：\n{str(e)}", parent=root)

def main():
    """主函数：自动路径，纯弹窗交互"""
    # 创建主窗口（基础容器）
    root = tk.Tk()
    root.title("迷你世界日志CSV数据拼接工具")
    root.geometry("400x100")  # 设置窗口大小
    root.resizable(False, False)  # 禁止调整窗口大小
    root.withdraw()  # 隐藏主窗口，仅显示弹窗

    # 1. 自动拼接日志文件路径（AppData\Roaming\miniworddata110\data\ss\TriggerScript.log）
    # 获取用户AppData\Roaming目录
    appdata_roaming = os.path.join(os.environ['USERPROFILE'], 'AppData', 'Roaming')
    log_file_path = os.path.join(appdata_roaming, 'miniworddata110', 'data', 'ss', 'TriggerScript.log')

    # 2. 自动拼接输出路径（py文件所在目录的csv文件夹）
    # 获取当前py文件所在目录
    py_dir = os.path.dirname(os.path.abspath(__file__))
    # 创建csv文件夹（不存在则创建）
    output_dir = os.path.join(py_dir, 'csv')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    # 输出文件命名
    output_csv_path = os.path.join(output_dir, "合并后的方块数据.csv")

    # 3. 执行数据提取和合并
    extract_and_merge_csv(log_file_path, output_csv_path, root)

    # 4. 退出程序
    root.destroy()

if __name__ == "__main__":
    main()
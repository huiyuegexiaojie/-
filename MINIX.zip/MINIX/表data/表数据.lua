-- 声明：小杰（qq：1695584750）制作，仅供研究禁止其他用途，后果自负。
-- 触发方式：玩家点击或放置任意方块触发
-- ===================== 1. 全局配置（完全保留原版，新增区块配置） =====================
local CONFIG = {
    -- 原版坐标配置（你可自定义修改）
    POS1 = {x = 4, y = 7, z = 37},
    POS2 = {x = 65, y = 64, z = -34},
    -- 新增区块采集配置（关键适配）
    BLOCK_SIZE = 32,          -- 32×32×32区块拆分
    PLAYER_OFFSET_Y = 7,      -- 玩家移动到区块顶部+7格
    -- 原版输出配置（完全保留）
    SEGMENT_THRESHOLD = 150,
    EMPTY_BLOCK_ID = 0,
    CSV_HEADER = "方块X坐标,方块Y坐标,方块Z坐标,方块ID,方块附加Data,方块名称"
}

-- ===================== 2. 基础工具函数（完全保留原版） =====================
local function getBlockId(x, y, z)
    local ret, id = Block:getBlockID(x, y, z)
    return ret == ErrorCode.OK and id or CONFIG.EMPTY_BLOCK_ID
end

local function getBlockData(x, y, z)
    local ret, data = Block:getBlockData(x, y, z)
    return ret == ErrorCode.OK and data or 0
end

local function getBlockName(blockId)
    local ret, name = Block:GetBlockDefName(blockId)
    local safeName = ret == ErrorCode.OK and name or "未知方块"
    return string.gsub(safeName, ",", "，")
end

local function formatCsvLine(x, y, z, blockId, blockData, blockName)
    return string.format("%d,%d,%d,%d,%d,%s", x, y, z, blockId, blockData, blockName)
end

local function printSegmentLog(segment, isLast, csvLines)
    local segTitle = isLast and string.format("数据分段%d（最后一段）", segment) 
                             or string.format("数据分段%d", segment)
    print("===== " .. segTitle .. " =====")
    print(table.concat(csvLines, "\n"))
    print("=====================")
end

-- ===================== 3. 新增：玩家移动/区块拆分核心函数（适配关键） =====================
-- 锁定/解锁玩家移动
local function lockPlayerMove(playerId, isLock)
    pcall(function()
        Player:changPlayerMoveType(playerId, isLock and 1 or 2)
        print(isLock and "[采集] 锁定玩家移动" or "[采集] 解锁玩家移动")
    end)
end

-- 移动玩家到区块上方+延迟加载（确保区块加载完成）
local function movePlayerToBlock(playerId, block)
    local targetX = math.floor((block.x1 + block.x2) / 2)
    local targetY = block.y2 + CONFIG.PLAYER_OFFSET_Y
    local targetZ = math.floor((block.z1 + block.z2) / 2)
    
    pcall(function()
        Player:setPosition(playerId, targetX, targetY, targetZ)
        print(string.format("[采集] 玩家已移动到区块%d上方：X=%d Y=%d Z=%d",
            block.idx, targetX, targetY, targetZ))
    end)
    -- 延迟0.5秒，确保区块完全加载
    pcall(function() threadpool:wait(0.5) end)
end

-- 拆分32×32×32区块（适配原版坐标配置）
local function splitTo32Blocks()
    local p1, p2 = CONFIG.POS1, CONFIG.POS2
    -- 计算坐标边界（保留原版逻辑）
    local area = {
        x1 = math.min(p1.x, p2.x), x2 = math.max(p1.x, p2.x),
        y1 = math.min(p1.y, p2.y), y2 = math.max(p1.y, p2.y),
        z1 = math.min(p1.z, p2.z), z2 = math.max(p1.z, p2.z)
    }
    print(string.format("[采集] 📏 扫描区域：X(%d~%d) Y(%d~%d) Z(%d~%d)",
        area.x1, area.x2, area.y1, area.y2, area.z1, area.z2))
    
    local blocks = {}
    local bs = CONFIG.BLOCK_SIZE
    -- 拆分32×32×32区块
    for xIdx = 0, math.ceil((area.x2 - area.x1) / bs) - 1 do
        for yIdx = 0, math.ceil((area.y2 - area.y1) / bs) - 1 do
            for zIdx = 0, math.ceil((area.z2 - area.z1) / bs) - 1 do
                local x1 = area.x1 + xIdx * bs
                local x2 = math.min(x1 + bs - 1, area.x2)
                local y1 = area.y1 + yIdx * bs
                local y2 = math.min(y1 + bs - 1, area.y2)
                local z1 = area.z1 + zIdx * bs
                local z2 = math.min(z1 + bs - 1, area.z2)
                table.insert(blocks, {
                    idx = #blocks + 1,
                    x1 = x1, x2 = x2, y1 = y1, y2 = y2, z1 = z1, z2 = z2
                })
            end
        end
    end
    print(string.format("[采集] 拆分完成：共%d个32×32×32区块", #blocks))
    return blocks
end

-- ===================== 4. 原版采集函数改造（仅适配区块遍历，逻辑完全不变） =====================
local function collectBlockData(playerId, block)
    local csvLines = {CONFIG.CSV_HEADER}
    local blockUniqueMap = {}
    local count = 0
    local segment = 1
    -- 仅替换遍历范围为当前区块（保留原版所有逻辑）
    local x1,x2,y1,y2,z1,z2 = block.x1,block.x2,block.y1,block.y2,block.z1,block.z2
    
    for x = x1, x2 do
        for y = y1, y2 do
            for z = z1, z2 do
                local blockId = getBlockId(x, y, z)
                if blockId ~= CONFIG.EMPTY_BLOCK_ID then
                    local uniqueKey = (x * 1000000) + (y * 1000) + z + (blockId * 1000000000)
                    if not blockUniqueMap[uniqueKey] then
                        local blockData = getBlockData(x, y, z)
                        local blockName = getBlockName(blockId)
                        table.insert(csvLines, formatCsvLine(x, y, z, blockId, blockData, blockName))
                        count = count + 1
                        blockUniqueMap[uniqueKey] = true
                        
                        if #csvLines >= CONFIG.SEGMENT_THRESHOLD then
                            printSegmentLog(segment, false, csvLines)
                            csvLines = {CONFIG.CSV_HEADER}
                            segment = segment + 1
                            print(string.format("[采集] 区块%d：已采集%d个方块，输出分段%d", block.idx, count, segment-1))
                        end
                    end
                end
            end
        end
    end
    
    if #csvLines > 1 then
        printSegmentLog(segment, true, csvLines)
    end
    print(string.format("[采集] 区块%d完成：共%d个唯一方块", block.idx, count))
    return count
end

-- ===================== 5. 主函数（新增分区块采集+玩家移动逻辑） =====================
local function mainCollect(playerId)
    print("[采集] ===== 原版脚本+分区块采集启动 =====")
    -- 1. 锁定玩家移动
    lockPlayerMove(playerId, true)
    
    -- 2. 拆分区块
    local blocks = splitTo32Blocks()
    if #blocks == 0 then
        print("[采集] 无有效区块，请检查坐标！")
        lockPlayerMove(playerId, false)
        return
    end
    
    -- 3. 逐区块移动+采集
    local totalCount = 0
    for _, block in ipairs(blocks) do
        movePlayerToBlock(playerId, block)
        local blockCount = collectBlockData(playerId, block)
        totalCount = totalCount + blockCount
    end
    
    -- 4. 解锁玩家+输出统计
    lockPlayerMove(playerId, false)
    print("[采集] ===== 全区域采集完成 ======")
    print(string.format("[采集] 总计：%d个唯一方块（已去重）", totalCount))
    print("[采集] 提示：合并所有分段日志（删除重复表头）即可用Excel解析")
end

-- ===================== 6. 触发事件（保留原版，适配玩家ID） =====================
-- 原版：点击方块触发
ScriptSupportEvent:registerEvent("Player.ClickBlock", function(e)
    local playerId = e.eventobjid
    -- 保留原版点击方块提示
    local x, y, z = e.x, e.y, e.z
    local blockId = getBlockId(x, y, z)
    local blockName = getBlockName(blockId)
    if blockId == CONFIG.EMPTY_BLOCK_ID then
        print(string.format("[采集] 点击位置：X=%d Y=%d Z=%d（空气方块）", x, y, z))
    else
        print(string.format("[采集] 点击方块：X=%d Y=%d Z=%d ID=%d 名称=%s", x, y, z, blockId, blockName))
    end
    -- 触发分区块采集
    mainCollect(playerId)
end)

-- 原版：游戏启动触发（适配玩家ID，取第一个玩家）
ScriptSupportEvent:registerEvent("Game.Start", function()
    pcall(function()
        -- 获取服务器第一个玩家ID
        local players = Player:getAllPlayers()
        if #players > 0 then
            local playerId = players[1]
            mainCollect(playerId)
        else
            print("[采集] 游戏启动时无在线玩家，请进入游戏后点击方块触发采集")
        end
    end)
end)

-- 脚本加载提示
print("[采集] 原版脚本+分区块采集已加载完成！")
print("[采集] 触发方式：1.放置任意方块（有玩家时） 2.点击任意方块")